package joao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException {

        Scanner entrada = new Scanner(System.in);
        System.out.println("Nome:");
        String nome = entrada.nextLine();
        System.out.println("Email:");
        String email = entrada.nextLine();

        String host = "localhost";       
        String dbname = "joao";        
        String port = "5432";
        String username = "postgres";
        String password = "postgres";
        String url = "jdbc:postgresql://"+host+":"+port+"/"+dbname;
      
        Connection conexao = DriverManager.getConnection(url, username, password);
        String sqlInsert = "INSERT INTO usuario (nome, email) VALUES (?, ?);";
        PreparedStatement preparedStatement = conexao.prepareStatement(sqlInsert);
        preparedStatement.setString(1, nome);
        preparedStatement.setString(2, email);
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        conexao.close();
        System.out.println((resultado == 1) ? "Sucesso!" : "Deu xabum!");
        entrada.close();

    }
}